package com.example.assignment_lyp_personal;

import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.util.Pair;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.example.assignment_lyp_personal.R;

import java.text.DecimalFormat;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

    private ArrayList<String> value = new ArrayList<>();
    private ArrayList<TableRow> rowsList = new ArrayList<>();
    private ArrayList<String> Restoreforbreakdown = new ArrayList<>();
    private String file_name = "";
    private String get = "";

    private float bill_total = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TableLayout tableLayout_first = findViewById(R.id.tablelayoutman);
        LinearLayout layout = findViewById(R.id.layoutme);



        Button myButton = findViewById(R.id.button_addrow);
        Button myButton1 = findViewById(R.id.button_return);
        Button myButton2 = findViewById(R.id.button_deleterow);
        Button myButton3 = findViewById(R.id.button_gonext);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);


        Intent intent = getIntent();
        value = intent.getStringArrayListExtra("STRING_LIST");
        Restoreforbreakdown = intent.getStringArrayListExtra("STRING2_LIST");

        EditText name = findViewById(R.id.textView_name);



         get = intent.getStringExtra("NAMING2");
        if (get != null) {
            name.setText(get);
            Log.d("message", get);
        }

        if (value != null) {
            for (String intse : value) {
                restoreTableRows();
                Total_all();
            }

        }
        else {
            // ArrayList is null, handle the absence of data here
            value = new ArrayList<>();
            // You can also perform other actions, like displaying a default table or prompting the user to add data.
        }

        file_name = intent.getStringExtra("FILE_NAME");
        if (file_name != null) {
            Log.d("get file data",file_name.toString());
            Pair<ArrayList<String>, ArrayList<String>> result = FileUtil.readTwoArrayListsFromFile(MainActivity.this, file_name);
            if (result != null) {
                value = result.first;
                Restoreforbreakdown = result.second;
                get = file_name.substring(0,file_name.length()-4);
                if(get != null){
                    Log.d("not empty",get);
                }
                else{
                    Log.d("empty","!");
                }
                name.setText(get);
                restoreTableRows();
            } else {
                // There was an error reading the file or the separator was not found
                Log.e("Error", "Failed to read the two ArrayLists from the file");
            }

        }
        else{
            Log.d("no file receved","sad");
        }

        name.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

                get = editable.toString();
            }
        });
        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // This is the function that will be executed when the button is clicked.
                // Add your code here.
                addDynamicTableRow();
            }
        });
        myButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the Start_page activity when myButton1 is clicked
                Intent intent = new Intent(MainActivity.this, Start_page.class);
                startActivity(intent);
            }
        });
        myButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // This is the function that will be executed when the button is clicked.
                // Add your code here.
                if(rowsList.size() != 1){
                    rowsList.remove(rowsList.size() - 1);
                    add_data();
                    rowsList.clear();
                    TableLayout table = findViewById(R.id.tablelayoutman);
                    table.removeAllViews();
                    restoreTableRows();
                }


            }
        });
        myButton3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                add_data();

                Intent intent = new Intent(MainActivity.this, breakdown.class);
                intent.putExtra("STRING_LIST", value);
                intent.putExtra("STRING2_LIST", Restoreforbreakdown);
                intent.putExtra("FLOAT_BILL",bill_total);
                intent.putExtra("NAMING",get);
                if(get != null){
                    Log.d("not empty",get);
                }
                else{
                    Log.d("empty","!");
                }
                startActivity(intent);
            }
        });
    }


    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            View v = getCurrentFocus();
            if ( v instanceof EditText) {
                Rect outRect = new Rect();
                v.getGlobalVisibleRect(outRect);
                if (!outRect.contains((int)event.getRawX(), (int)event.getRawY())) {
                    v.clearFocus();
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                }
            }
        }
        return super.dispatchTouchEvent( event );
    }
    //add_data() : convert the data stored in each tablerow into a string, and store in ArrayList<String> Restoreforbreakdown
    private void add_data(){
        value.clear();
        for (TableRow tableRow : rowsList) {
            StringBuilder rowData = new StringBuilder();
            int childCount = tableRow.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View child = tableRow.getChildAt(i);
                if (child instanceof EditText) {
                    EditText editText = (EditText) child;
                    String text = editText.getText().toString();
                    rowData.append(text).append("/");
                }
            }
            value.add(rowData.toString().trim());
        }
    }
    //restoreTableRows() : restore each tablerow info from a string and add into the tablelayout
    private void restoreTableRows() {
        TableLayout tableLayout = findViewById(R.id.tablelayoutman);
        tableLayout.removeAllViews(); // Clear any existing rows before restoring

        rowsList.clear(); // Clear the rowsList to avoid duplication

        for (String text : value) {
            TableRow tableRow = new TableRow(this);
            tableRow.setLayoutParams(new TableLayout.LayoutParams(
                    TableLayout.LayoutParams.MATCH_PARENT,
                    TableLayout.LayoutParams.MATCH_PARENT
            ));
            tableRow.setPadding(0, 5, 0, 0);

            ArrayList<EditText> aray = new ArrayList<>();

            String[] splitStrings = text.split("/");
            for (String value : splitStrings) {
                EditText editText = new EditText(this);
                editText.setText(value);
                setTextViewProperties(editText);
                aray.add(editText);
                //tableRow.addView(editText);
            }
            int newRowNumber = rowsList.size() + 1;

            aray.get(0).setText(String.valueOf(newRowNumber));
            aray.get(1).addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                }

                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                }



                @Override
                public void afterTextChanged(Editable editable) {

                    int count = editable.length();
                    if(count > 5){
                        editable.delete(5,6);
                    }

                }
            });
            aray.get(2).addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                }

                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                    String newText = charSequence.toString();

                    // Check if the current text starts with "0"
                    if (newText.startsWith("0")) {
                        // Replace "0" with an empty string to clear it
                        newText = newText.replaceFirst("^0", "");

                        // Update the text in the EditText
                        EditText editText = (EditText) getCurrentFocus();
                        if (editText != null) {
                            editText.setText(newText);

                            // Move the cursor to the end of the text
                            editText.setSelection(newText.length());
                        }
                    }
                }



                @Override
                public void afterTextChanged(Editable editable) {



                    String input = editable.toString();
                    String newInput;
                    int count = 0;
                    int maxDigitsBeforeDecimal = 4;
                    int maxDigitsAfterDecimal = 2;

// Check if the input has more than allowed characters before the decimal point
                    int decimalIndex = input.indexOf('.');
                    int lengthBeforeDecimal = (decimalIndex == -1) ? input.length() : decimalIndex;
                    if (lengthBeforeDecimal > maxDigitsBeforeDecimal) {
                        editable.delete(maxDigitsBeforeDecimal, input.length());
                    }

                    for (int i = 0; i < editable.length(); i++) {
                        char ch = editable.charAt(i);
                        if (!Character.isDigit(ch) && ch != '.') {
                            editable.delete(i, i + 1);
                            i--; // Decrement the loop counter to recheck the character at the same index
                        }
                        if (ch == '.' && count == 0) {
                            count++;
                        } else if (ch == '.' && count == 1) {
                            editable.delete(i, i + 1);
                            i--;
                        }
                    }

// Remove extra decimal places beyond two
                    if (decimalIndex != -1 && input.length() - decimalIndex > maxDigitsAfterDecimal + 1) {
                        editable.delete(decimalIndex + maxDigitsAfterDecimal + 1, editable.length());
                    }

                    newInput = editable.toString();




                    // Update the value of column5 based on the entered value in column3
                    String text1 = newInput;
                    float value3 = text1.isEmpty() ? 0 : Float.parseFloat(text1);
                    String text = aray.get(3).getText().toString();
                    int value4 = text.isEmpty() ? 0 : Integer.parseInt(text);
                    aray.get(4).setText("RM" + String.valueOf(value3 * (float)value4));
                    Total_all();
                }
            });

            aray.get(3).addTextChangedListener(new TextWatcher() {



                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {



                }

                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                    String newText = charSequence.toString();

                    // Check if the current text starts with "0"
                    if (newText.startsWith("0")) {
                        // Replace "0" with an empty string to clear it
                        newText = newText.replaceFirst("^0", "");

                        // Update the text in the EditText
                        EditText editText = (EditText) getCurrentFocus();
                        if (editText != null) {
                            editText.setText(newText);

                            // Move the cursor to the end of the text
                            editText.setSelection(newText.length());
                        }
                    }
                }


                @Override
                public void afterTextChanged(Editable editable) {

                    String input = editable.toString();
                    String newinput;

                    // Check if the input has more than two characters before the decimal point
                    int decimalIndex = input.length();
                    if (decimalIndex != -1 && decimalIndex > 2) {
                        editable.delete(2, 3);
                    }
                    for (int i = 0; i < editable.length(); i++) {
                        char ch = editable.charAt(i);
                        if (!Character.isDigit(ch)) {
                            editable.delete(i, i + 1);
                            i--; // Decrement the loop counter to recheck the character at the same index
                        }
                    }

                    newinput = editable.toString();
                    // Update the value of column5 based on the entered value in column4
                    String text1 = aray.get(2).getText().toString();
                    float value3 = text1.isEmpty() ? 0 : Float.parseFloat(text1);
                    String text = newinput;
                    int value4 = text.isEmpty() ? 0 : Integer.parseInt(text);
                    aray.get(4).setText("RM" + (value3 * (float) value4));
                    Total_all();
                }
            });
            aray.get(2).setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (!hasFocus) {
                        String input = aray.get(2).getText().toString();
                        if (input.isEmpty()) {
                            aray.get(2).setText("0");
                        }
                    }
                }
            });

            aray.get(3).setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (!hasFocus) {
                        String input = aray.get(3).getText().toString();
                        if (input.isEmpty()) {
                            aray.get(3).setText("0");
                        }
                    }
                }
            });
            aray.get(1).setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (!hasFocus) {
                        String input = aray.get(1).getText().toString();
                        if (input.isEmpty()) {
                            aray.get(1).setText("Item");
                        }
                    }
                }
            });
            for (TextView t:aray){
                tableRow.addView(t);
            }
            tableLayout.addView(tableRow);
            rowsList.add(tableRow);
            Total_all();
        }
    }
    //addDynamicTableRow2() : users can dynamically add tablerow into tablelayout
    private void addDynamicTableRow() {
        TableLayout tableLayout = findViewById(R.id.tablelayoutman);
        TableRow tableRow = new TableRow(this);
        tableRow.setLayoutParams(new TableLayout.LayoutParams(
                TableLayout.LayoutParams.MATCH_PARENT,
                TableLayout.LayoutParams.MATCH_PARENT
        ));
        tableRow.setPadding(0, 5, 0, 0);
        EditText column1 = new EditText(this);
        EditText column2 = new EditText(this);
        EditText column3 = new EditText(this);
        EditText column4 = new EditText(this);
        EditText column5 = new EditText(this);


        int newRowNumber = rowsList.size() + 1;

        column1.setText(String.valueOf(newRowNumber));
        column2.setText("item");
        column3.setText("0");
        column4.setText("0");
        column5.setText("RM0");



        setTextViewProperties(column1);
        setTextViewProperties(column2);
        setTextViewProperties(column3);
        setTextViewProperties(column4);
        setTextViewProperties(column5);
        column2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }



            @Override
            public void afterTextChanged(Editable editable) {

                int count = editable.length();
                if(count > 5){
                    editable.delete(5,6);
                }

            }
        });
        column3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String newText = charSequence.toString();

                // Check if the current text starts with "0"
                if (newText.startsWith("0")) {
                    // Replace "0" with an empty string to clear it
                    newText = newText.replaceFirst("^0", "");

                    // Update the text in the EditText
                    EditText editText = (EditText) getCurrentFocus();
                    if (editText != null) {
                        editText.setText(newText);

                        // Move the cursor to the end of the text
                        editText.setSelection(newText.length());
                    }
                }
            }



            @Override
            public void afterTextChanged(Editable editable) {



                String input = editable.toString();
                String newInput;
                int count = 0;
                int maxDigitsBeforeDecimal = 4;
                int maxDigitsAfterDecimal = 2;

// Check if the input has more than allowed characters before the decimal point
                int decimalIndex = input.indexOf('.');
                int lengthBeforeDecimal = (decimalIndex == -1) ? input.length() : decimalIndex;
                if (lengthBeforeDecimal > maxDigitsBeforeDecimal) {
                    editable.delete(maxDigitsBeforeDecimal, input.length());
                }

                for (int i = 0; i < editable.length(); i++) {
                    char ch = editable.charAt(i);
                    if (!Character.isDigit(ch) && ch != '.') {
                        editable.delete(i, i + 1);
                        i--; // Decrement the loop counter to recheck the character at the same index
                    }
                    if (ch == '.' && count == 0) {
                        count++;
                    } else if (ch == '.' && count == 1) {
                        editable.delete(i, i + 1);
                        i--;
                    }
                }

// Remove extra decimal places beyond two
                if (decimalIndex != -1 && input.length() - decimalIndex > maxDigitsAfterDecimal + 1) {
                    editable.delete(decimalIndex + maxDigitsAfterDecimal + 1, editable.length());
                }

                newInput = editable.toString();




                // Update the value of column5 based on the entered value in column3
                String text1 = newInput;
                float value3 = text1.isEmpty() ? 0 : Float.parseFloat(text1);
                String text = column4.getText().toString();
                int value4 = text.isEmpty() ? 0 : Integer.parseInt(text);
                column5.setText("RM" + String.valueOf(value3 * (float)value4));
                Total_all();
            }
        });

        column4.addTextChangedListener(new TextWatcher() {



            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {



            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            String newText = charSequence.toString();

            // Check if the current text starts with "0"
            if (newText.startsWith("0")) {
                // Replace "0" with an empty string to clear it
                newText = newText.replaceFirst("^0", "");

                // Update the text in the EditText
                EditText editText = (EditText) getCurrentFocus();
                if (editText != null) {
                    editText.setText(newText);

                    // Move the cursor to the end of the text
                    editText.setSelection(newText.length());
                }
            }
        }


            @Override
            public void afterTextChanged(Editable editable) {

                String input = editable.toString();
                String newinput;

                // Check if the input has more than two characters before the decimal point
                int decimalIndex = input.length();
                if (decimalIndex != -1 && decimalIndex > 2) {
                    editable.delete(2, 3);
                }
                for (int i = 0; i < editable.length(); i++) {
                    char ch = editable.charAt(i);
                    if (!Character.isDigit(ch)) {
                        editable.delete(i, i + 1);
                        i--; // Decrement the loop counter to recheck the character at the same index
                    }
                }

                newinput = editable.toString();
                // Update the value of column5 based on the entered value in column4
                String text1 = column3.getText().toString();
                float value3 = text1.isEmpty() ? 0 : Float.parseFloat(text1);
                String text = newinput;
                int value4 = text.isEmpty() ? 0 : Integer.parseInt(text);
                column5.setText("RM" + (value3 * (float) value4));
                Total_all();
            }
        });
        column3.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    String input = column3.getText().toString();
                    if (input.isEmpty()) {
                        column3.setText("0");
                    }
                }
            }
        });

        column4.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    String input = column4.getText().toString();
                    if (input.isEmpty()) {
                        column4.setText("0");
                    }
                }
            }
        });
        column2.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    String input = column2.getText().toString();
                    if (input.isEmpty()) {
                        column2.setText("Item");
                    }
                }
            }
        });



        tableRow.addView(column1);
        tableRow.addView(column2);
        tableRow.addView(column3);
        tableRow.addView(column4);
        tableRow.addView(column5);

        // Add the TableRow to the TableLayout
        tableLayout.addView(tableRow);

        // Add the TableRow to the ArrayList
        rowsList.add(tableRow);
    }
    //setTextViewProperties () : to set the properties of each editText that will be add into a same tablerow
    private void setTextViewProperties(EditText edittext) {
        edittext.setLayoutParams(new TableRow.LayoutParams(
                TableRow.LayoutParams.WRAP_CONTENT,
                TableRow.LayoutParams.MATCH_PARENT,1 // Set height to WRAP_CONTENT
        ));
        edittext.setTextSize(16f);
        edittext.setBackgroundResource(R.drawable.outputbox);
        edittext.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        edittext.setTextColor(getResources().getColor(android.R.color.white));
    }
    //Total_all () : to sum up the price of each items and return the final total value
    private void Total_all(){
        TextView totaloutput = findViewById(R.id.Totalall);

        float Total = 0;

        for(TableRow j:rowsList){
            View child = j.getChildAt(4);
            if (child instanceof TextView) {
                TextView totalchild = (TextView) child;
                String text = totalchild.getText().toString().substring(2);
                Total += Float.parseFloat(text);
            }

        }
        DecimalFormat decimalFormat = new DecimalFormat("#.##");

        // Use the format method to round up the value to two decimal points
        String roundedValue = decimalFormat.format(Total);

        // Convert the result back to a float if needed
        float roundedFloat = Float.parseFloat(roundedValue);

        totaloutput.setText("RM " + Float.toString(roundedFloat));
        bill_total = Total;
    }

}
