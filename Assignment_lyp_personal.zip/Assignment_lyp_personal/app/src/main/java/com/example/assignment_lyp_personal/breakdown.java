package com.example.assignment_lyp_personal;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.example.assignment_lyp_personal.R;

import java.util.ArrayList;

public class breakdown extends AppCompatActivity {

    private ArrayList<TableRow> rowsList2 = new ArrayList<>();
    private ArrayList<String> dataList = new ArrayList<>();
    private ArrayList<String> breakdown_info = new ArrayList<>();
    private String naming2 ="";
    float bill = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.breakdown);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        TextView showtotal = findViewById(R.id.totalBill);
        Intent intent = getIntent();
        dataList = intent.getStringArrayListExtra("STRING_LIST");
        breakdown_info = intent.getStringArrayListExtra("STRING2_LIST");
        bill = intent.getFloatExtra("FLOAT_BILL",bill);
        naming2 = intent.getStringExtra("NAMING");
        if(naming2 != null){
            Log.d("not empty",naming2);
        }
        else{
            Log.d("empty","!");
        }
        showtotal.setText("RM " + Float.toString(bill));

        // Check if the ArrayLists are null before accessing their elements
        if (dataList != null) {
            for (String savedValue : dataList) {
                Log.d("get Data", savedValue);
            }
        } else {
            dataList = new ArrayList<>();
            // Handle the absence of data in dataList here (if needed).
        }

        if (breakdown_info != null) {
            for (String value : breakdown_info) {
                // Log the received values
                Log.d("Received Data", value);
            }
            restoreTableRows();
        } else {
            breakdown_info = new ArrayList<>();
            // Handle the absence of data in breakdown_info here (if needed).
        }

        TableLayout tableLayout_second = findViewById(R.id.tablebreakdwon);
        Button myButton = findViewById(R.id.button_addrow2);
        Button myButton2 = findViewById(R.id.button_deleterow2);
        Button mybutton_save = findViewById(R.id.save);
        Button myButton3 = findViewById(R.id.buttonreturn2);
        Button myBUtton4 = findViewById(R.id.distribute);

        mybutton_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                add_data();
                if((total_hundred() != bill)&(!rowsList2.isEmpty())){
                    AlertDialogHelper.showAlertDialog(breakdown.this, "Save Result?", "The breakdown is incorrect. Do you want to save the result?",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    // Code to handle the positive button click ("Yes, save")
                                    FileUtil.saveTwoArrayListsToFile(breakdown.this, dataList, breakdown_info, String.format(naming2 + ".txt"));
                                    Intent intent = new Intent(breakdown.this, Start_page.class);
                                    startActivity(intent);
                                }
                            },
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    // Code to handle the negative button click ("No, discard")

                                }
                            });
                }
                else if((total_hundred() == bill)&(!rowsList2.isEmpty())){
                    FileUtil.saveTwoArrayListsToFile(breakdown.this, dataList, breakdown_info, String.format(naming2 + ".txt"));
                    Intent intent = new Intent(breakdown.this, Start_page.class);
                    startActivity(intent);
                }
                else if(rowsList2.isEmpty()){

                }
            }
        });
        myButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(rowsList2.size() != 1){
                    rowsList2.remove(rowsList2.size() - 1);
                    add_data();
                    rowsList2.clear();
                    TableLayout table = findViewById(R.id.tablebreakdwon);
                    table.removeAllViews();
                    restoreTableRows();
                }

            }
        });
        myBUtton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                distributetotal();
            }
        });

        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // This is the function that will be executed when the button is clicked.
                // Add your code here.
                addDynamicTableRow2();
            }
        });
        myButton3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(breakdown.this, MainActivity.class);

                add_data();

                intent.putExtra("STRING2_LIST", breakdown_info);
                for (String value : breakdown_info) {
                    // Log the received values
                    Log.d("sent Data", value);
                }
                intent.putExtra("STRING_LIST", dataList);
                intent.putExtra("NAMING2", naming2);
                startActivity(intent);
            }
        });
    }
    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            View v = getCurrentFocus();
            if ( v instanceof EditText) {
                Rect outRect = new Rect();
                v.getGlobalVisibleRect(outRect);
                if (!outRect.contains((int)event.getRawX(), (int)event.getRawY())) {
                    v.clearFocus();
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                }
            }
        }
        return super.dispatchTouchEvent( event );
    }
    //addDynamicTableRow2() : users can dynamically add tablerow into tablelayout
    private void addDynamicTableRow2() {
        TableLayout tableLayout = findViewById(R.id.tablebreakdwon);
        TableRow tableRow = new TableRow(this);
        tableRow.setLayoutParams(new TableLayout.LayoutParams(
                TableLayout.LayoutParams.MATCH_PARENT,
                TableLayout.LayoutParams.MATCH_PARENT
        ));
        tableRow.setPadding(0, 5, 0, 0);
        EditText column1 = new EditText(this);
        EditText column2 = new EditText(this);
        EditText column3 = new EditText(this);
        EditText column4 = new EditText(this);



        int newRowNumber = rowsList2.size() + 1;

        column1.setText(String.valueOf(newRowNumber));
        column2.setText("name");
        column3.setText("0");
        column4.setText("RM 0");


        setTextViewProperties(column1);
        setTextViewProperties(column2);
        setTextViewProperties(column3);
        setTextViewProperties(column4);

        column2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }



            @Override
            public void afterTextChanged(Editable editable) {

                int count = editable.length();
                if(count > 8){
                    editable.delete(8,9);
                }

            }
        });

        column3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String newText = charSequence.toString();

                // Check if the current text starts with "0"
                if (newText.startsWith("0")) {
                    // Replace "0" with an empty string to clear it
                    newText = newText.replaceFirst("^0", "");

                    // Update the text in the EditText
                    EditText editText = (EditText) getCurrentFocus();
                    if (editText != null) {
                        editText.setText(newText);

                        // Move the cursor to the end of the text
                        editText.setSelection(newText.length());
                    }
                }
            }



            @Override
            public void afterTextChanged(Editable editable) {



                String input = editable.toString().trim();
                int maxDigitsBeforeDecimal = 3;
                int maxDigitsAfterDecimal = 2;

                // Check if the input has more than allowed characters before the decimal point
                int decimalIndex = input.indexOf('.');
                int lengthBeforeDecimal = (decimalIndex == -1) ? input.length() : decimalIndex;
                if (lengthBeforeDecimal > maxDigitsBeforeDecimal) {
                    editable.delete(maxDigitsBeforeDecimal, input.length());
                }

                int count = 0;
                for (int i = 0; i < editable.length(); i++) {
                    char ch = editable.charAt(i);
                    if (!Character.isDigit(ch) && ch != '.') {
                        editable.delete(i, i + 1);
                        i--; // Decrement the loop counter to recheck the character at the same index
                    }
                    if (ch == '.' && count == 0) {
                        count++;
                    } else if (ch == '.' && count == 1) {
                        editable.delete(i, i + 1);
                        i--;
                    }
                }

                // Remove extra decimal places beyond two
                if (decimalIndex != -1 && input.length() - decimalIndex > maxDigitsAfterDecimal + 1) {
                    editable.delete(decimalIndex + maxDigitsAfterDecimal + 1, editable.length());
                }

                String newInput = editable.toString().trim();

                // Update the value of column5 based on the entered value in column3
                String text1 = newInput;
                if (text1.isEmpty()) {
                    column4.setText("RM 0");
                } else {
                    float percent = Float.parseFloat(text1);
                    column4.setText("RM " + Float.toString((bill * percent) / 100));
                }

            }
        });
        column2.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    String input = column2.getText().toString();
                    if (input.isEmpty()) {
                        column2.setText("Person");
                    }
                }
            }
        });
        column3.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    String input = column3.getText().toString();
                    if (input.isEmpty()) {
                        column3.setText("0");
                    }
                }
            }
        });
        column4.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    String input = column4.getText().toString();
                    if (input.isEmpty()) {
                        column4.setText("RM 0");
                        column3.setText("0");
                    }
                    else{
                        float percent = (Float.parseFloat(input.substring(3))/bill)*100;
                        column3.setText(Float.toString(percent));
                        column4.setText(input);
                    }
                }
            }
        });
        tableRow.addView(column1);
        tableRow.addView(column2);
        tableRow.addView(column3);
        tableRow.addView(column4);


        // Add the TableRow to the TableLayout
        tableLayout.addView(tableRow);

        // Add the TableRow to the ArrayList
        rowsList2.add(tableRow);
    }
    //setTextViewProperties () : to set the properties of each editText that will be add into a same tablerow
    private void setTextViewProperties(EditText edittext) {
        edittext.setLayoutParams(new TableRow.LayoutParams(
                TableRow.LayoutParams.WRAP_CONTENT,
                TableRow.LayoutParams.WRAP_CONTENT,1 // Set height to WRAP_CONTENT
        ));
        edittext.setBackgroundResource(R.drawable.outputbox);
        edittext.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_PERSON_NAME);
        edittext.setTextColor(getResources().getColor(android.R.color.white));
    }
    //add_data() : convert the data stored in each tablerow into a string, and store in ArrayList<String> breakdown_info
    private void add_data(){
        breakdown_info.clear();
        for (String value : breakdown_info) {
            // Log the received values
            Log.d("Received3 Data", value);
        }
        for (TableRow tableRow : rowsList2) {
            StringBuilder rowData = new StringBuilder();
            int childCount = tableRow.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View child = tableRow.getChildAt(i);
                if (child instanceof EditText) {
                    EditText editText = (EditText) child;
                    String text = editText.getText().toString();
                    rowData.append(text).append("/");
                }
            }
            breakdown_info.add(rowData.toString().trim());
        }
    }
    //restoreTableRows() : restore each tablerow info from a string and add into the tablelayout
    private void restoreTableRows() {
        TableLayout tableLayout = findViewById(R.id.tablebreakdwon);
        tableLayout.removeAllViews(); // Clear any existing rows before restoring

        rowsList2.clear(); // Clear the rowsList to avoid duplication

        for (String text : breakdown_info) {
            TableRow tableRow = new TableRow(this);
            tableRow.setLayoutParams(new TableLayout.LayoutParams(
                    TableLayout.LayoutParams.MATCH_PARENT,
                    TableLayout.LayoutParams.MATCH_PARENT
            ));
            tableRow.setPadding(0, 5, 0, 0);

            ArrayList<EditText> aray = new ArrayList<>();

            String[] splitStrings = text.split("/");
            for (String value : splitStrings) {
                EditText editText = new EditText(this);
                editText.setText(value);
                setTextViewProperties(editText);
                aray.add(editText);
            }
            aray.get(1).addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                }

                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                }



                @Override
                public void afterTextChanged(Editable editable) {

                    int count = editable.length();
                    if(count > 8){
                        editable.delete(8,9);
                    }

                }
            });
            aray.get(2).addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                }

                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                    String newText = charSequence.toString();

                    // Check if the current text starts with "0"
                    if (newText.startsWith("0")) {
                        // Replace "0" with an empty string to clear it
                        newText = newText.replaceFirst("^0", "");

                        // Update the text in the EditText
                        EditText editText = (EditText) getCurrentFocus();
                        if (editText != null) {
                            editText.setText(newText);

                            // Move the cursor to the end of the text
                            editText.setSelection(newText.length());
                        }
                    }
                }



                @Override
                public void afterTextChanged(Editable editable) {



                    String input = editable.toString().trim();
                    int maxDigitsBeforeDecimal = 3;
                    int maxDigitsAfterDecimal = 2;

                    // Check if the input has more than allowed characters before the decimal point
                    int decimalIndex = input.indexOf('.');
                    int lengthBeforeDecimal = (decimalIndex == -1) ? input.length() : decimalIndex;
                    if (lengthBeforeDecimal > maxDigitsBeforeDecimal) {
                        editable.delete(maxDigitsBeforeDecimal, input.length());
                    }

                    int count = 0;
                    for (int i = 0; i < editable.length(); i++) {
                        char ch = editable.charAt(i);
                        if (!Character.isDigit(ch) && ch != '.') {
                            editable.delete(i, i + 1);
                            i--; // Decrement the loop counter to recheck the character at the same index
                        }
                        if (ch == '.' && count == 0) {
                            count++;
                        } else if (ch == '.' && count == 1) {
                            editable.delete(i, i + 1);
                            i--;
                        }
                    }

                    // Remove extra decimal places beyond two
                    if (decimalIndex != -1 && input.length() - decimalIndex > maxDigitsAfterDecimal + 1) {
                        editable.delete(decimalIndex + maxDigitsAfterDecimal + 1, editable.length());
                    }

                    String newInput = editable.toString().trim();

                    // Update the value of column5 based on the entered value in column3
                    String text1 = newInput;
                    if (text1.isEmpty()) {
                        aray.get(3).setText("RM 0");
                    } else {
                        float percent = Float.parseFloat(text1);
                        aray.get(3).setText("RM " + Float.toString((bill * percent) / 100));
                    }

                }
            });
            aray.get(1).setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (!hasFocus) {
                        String input = aray.get(1).getText().toString();
                        if (input.isEmpty()) {
                            aray.get(1).setText("Person");
                        }
                    }
                }
            });

            aray.get(2).setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (!hasFocus) {
                        String input = aray.get(2).getText().toString();
                        if (input.isEmpty()) {
                            aray.get(2).setText("0");
                        }

                    }
                }
            });
            aray.get(3).setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (!hasFocus) {
                        String input = aray.get(3).getText().toString();
                        if (input.isEmpty()) {
                            aray.get(3).setText("RM 0");
                            aray.get(2).setText("0");
                        }
                        else{
                            float percent = (Float.parseFloat(input.substring(3))/bill)*100;
                            aray.get(2).setText(Float.toString(percent));
                            aray.get(3).setText(input);
                        }
                    }
                }
            });
            for (TextView t:aray){
                tableRow.addView(t);
            }
            tableLayout.addView(tableRow);
            rowsList2.add(tableRow);
        }
    }
    //distributetotal() : to perform equalbreakdown of the bill
    private void distributetotal(){
        int count = rowsList2.size();

        for (TableRow tableRow : rowsList2) {
            int childCount = tableRow.getChildCount();

                View child = tableRow.getChildAt(2);
                if (child instanceof EditText) {
                    EditText editText = (EditText) child;
                    editText.setText(Float.toString((100/count)));
                }

        }

    }
    //total_hundred() : sum up the total value of every tablerow and return the value
    private float total_hundred(){
        int count = rowsList2.size();
        float total2 = 0;
        for (TableRow tableRow : rowsList2) {
            int childCount = tableRow.getChildCount();

            View child = tableRow.getChildAt(3);
            if (child instanceof EditText) {
                EditText editText = (EditText) child;
                String ya = editText.getText().toString();
                total2 += Float.parseFloat(ya.substring(3));
            }

        }

        return total2;
    }
}
