package com.example.assignment_lyp_personal;

import android.content.Context;
import android.util.Log;
import android.util.Pair;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;

public class FileUtil {

    public static void saveTwoArrayListsToFile(Context context, ArrayList<String> list1, ArrayList<String> list2, String fileName) {
        StringBuilder stringBuilder = new StringBuilder();

        // Combine list1 elements into a single string
        for (String item : list1) {
            stringBuilder.append(item).append("@");

        }

        // Add a separator to distinguish between the two lists
        stringBuilder.append("-");

        // Combine list2 elements into the same string
        for (String item : list2) {
            stringBuilder.append(item).append("@");
        }

        try {
            FileOutputStream fos = context.openFileOutput(fileName, Context.MODE_PRIVATE);
            fos.write(stringBuilder.toString().getBytes());
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static Pair<ArrayList<String>, ArrayList<String>> readTwoArrayListsFromFile(Context context, String fileName) {
        try {
            InputStream is = context.openFileInput(fileName);
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String line = br.readLine();

            // Find the index of the separator
            int separatorIndex = line.indexOf("-");
            if (separatorIndex != -1) {
                String list1String = line.substring(0, separatorIndex);
                String list2String = line.substring(separatorIndex + 1);

                // Split the strings based on the "@" separator and convert them back to ArrayLists
                String[] list1Array = list1String.split("@");
                String[] list2Array = list2String.split("@");
                ArrayList<String> list1 = new ArrayList<>(Arrays.asList(list1Array));
                ArrayList<String> list2 = new ArrayList<>(Arrays.asList(list2Array));

                br.close();
                is.close();

                return new Pair<>(list1, list2);
            } else {
                // The separator was not found in the text
                br.close();
                is.close();
                return null;
            }
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
