package com.example.assignment_lyp_personal;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.example.assignment_lyp_personal.R;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Start_page extends AppCompatActivity {

    private ListView listView;
    private ArrayAdapter<String> adapter;
    private List<String> fileList;
    private int count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.start_page);

        listView = findViewById(R.id.listviewonly);
        fileList = new ArrayList<>();

        Button button1 = findViewById(R.id.button_add);
        Button button2 = findViewById(R.id.button_delete);
        // Call the method to save data to internal storage

        // Get the list of files in the internal storage directory
        File internalStorageDir = getFilesDir();
        File[] files = internalStorageDir.listFiles();

        if (files != null) {
            for (File file : files) {
                fileList.add(file.getName().substring(0,file.getName().length()-4));
            }
        }

        // Display the list of files in the ListView
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, fileList);
        listView.setAdapter(adapter);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Start_page.this, MainActivity.class);
                startActivity(intent);
            }
        });
        listView.setOnItemClickListener((parent, view, position, id) -> {
            if (count == 0) {
                // Normal item click behavior
                String fileName = adapter.getItem(position);
                String combinestr = fileName + ".txt";
                openFileContentActivity(combinestr);
            } else if (count == 1) {
                // File deletion mode is enabled
                String fileName = adapter.getItem(position);
                String combinestr = fileName + ".txt";
                // Remove the file name from the fileList
                fileList.remove(fileName);

                // Create a File object with the directory path and file name
                File fileToDelete = new File(getFilesDir(), combinestr);

                // Check if the file exists before attempting to delete it
                if (fileToDelete.exists()) {
                    // Attempt to delete the file
                    boolean isDeleted = fileToDelete.delete();

                    if (isDeleted) {
                        System.out.println("File deleted successfully.");
                    } else {
                        System.out.println("Failed to delete the file.");
                    }
                } else {
                    System.out.println("File does not exist at the specified path.");
                }

                // Update the ListView with the modified fileList
                adapter.notifyDataSetChanged();
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (count == 0) {
                    count = 1;
                    button2.setBackgroundResource(R.drawable.black);
                } else if (count == 1) {
                    count = 0;
                    button2.setBackgroundResource(R.drawable.button_plusminus);
                }
            }
        });

    }
    // load the specific file data into the new activity
    private void openFileContentActivity(String fileName) {
        Intent intent = new Intent(Start_page.this, MainActivity.class);
        intent.putExtra("FILE_NAME", fileName);
        startActivity(intent);
    }
}