package com.example.assignment_lyp_personal;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
// a alertdialog created to alert users on certain condition and perform different function based on the button they click
public class AlertDialogHelper {
    public static void showAlertDialog(Context context, String title, String message,
                                       DialogInterface.OnClickListener positiveListener,
                                       DialogInterface.OnClickListener negativeListener) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(title)
                .setMessage(message)
                .setPositiveButton("Yes, save", positiveListener)
                .setNegativeButton("No, discard", negativeListener)
                .create()
                .show();
    }
}